package com.bear.hospital.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bear.hospital.pojo.Admin;


public interface AdminMapper extends BaseMapper<Admin> {
}
