package com.bear.hospital.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bear.hospital.pojo.Checks;

public interface CheckMapper extends BaseMapper<Checks> {
}
