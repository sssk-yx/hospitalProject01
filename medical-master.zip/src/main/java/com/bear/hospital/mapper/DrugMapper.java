package com.bear.hospital.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.bear.hospital.pojo.Drug;

public interface DrugMapper extends BaseMapper<Drug> {
}
